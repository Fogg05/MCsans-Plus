


   名称: MCsans+
   作者: 零雾〇五 Fogg05
   团队: 异创Special 我的世界组件开发组

● 作品基于 MiSans
https://hyperos.mi.com/font

● 作品发布
https://github.com/Fogg05/mcsans-plus



   Title: MCsans+
   Author: 零雾〇五 Fogg05
   Team: 异创Special Minecraft MOD Development

● This pack is based on MiSans
https://hyperos.mi.com/font

● Github of this pack
https://github.com/Fogg05/mcsans-plus



