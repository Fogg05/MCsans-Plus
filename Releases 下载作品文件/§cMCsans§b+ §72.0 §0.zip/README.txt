


   名称: MCsans+
   作者: 零雾〇五 Fogg05

● 作品基于 MiSans
https://hyperos.mi.com/font

● 作品发布
https://github.com/Fogg05/mcsans-plus



   Title: MCsans+
   Author: 零雾〇五 Fogg05

● This pack is based on MiSans
https://hyperos.mi.com/font

● Github of this pack
https://github.com/Fogg05/mcsans-plus



